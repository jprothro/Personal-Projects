# Jaden Prothro
# create project

import csv
import time
import random
import math

# ask for game style/game using files. File will contain premium symbols and type of game
def askGames(count):
    print(f"Please pick your game type and symbols")
    print()
    count += 1
    with open("slot_symbols.csv", "r") as f:
        fReader = csv.reader(f, delimiter=",")
        x=0
        
        for row in fReader:
            if x == 0:
                print("%-6s %-14s %-10s %-10s %-10s %-10s %-10s" %("", row[0], row[1], row[2], row[3], row[4], row[5]))
            else:
                print("%-10s %-10s %-10s %-10s %-10s %-10s %-10s" %(f"Option {x}", row[0], row[1], row[2], row[3], row[4], row[5]))
            x+=1
        print()
        option = input("Enter option: ")
        while not option.isdigit() or int(option) > x-count:
            option = input("Enter option: ")
        option = int(option)

    with open("slot_symbols.csv", "r") as f:
        fReader = csv.reader(f, delimiter=",")
        game = []
        k = 0
        for row in fReader:
            if k == option:
                i = 0
                while i < len(row):
                    game.append(row[i])
                    i+=1
            k+=1
        return game
        
# introduces and asks for starting balance and game type
print("Welcome to Jaden's Slot Machine")
balance = input("What is your starting balance?\nBalance: $")
while not balance.isdigit():
    balance = input("Please enter a valid number\nBalance: $")
balance = int(balance)
    
game = askGames(0)

gameType = game[0]
prem1 = game[1]
prem2 = game[2]
prem3 = game[3]
prem4 = game[4]
prem5 = game[5]

# defining percent that symbols will show up
percent1 = 125 #W
percent2 = 155 #Q
percent3 = 150 #K
percent4 = 140 #A
percentP1 = 100 #prem1
percentP2 = 90 #prem2
percentP3 = 80 #prem3
percentP4 = 80 #prem4
percentP5 = 70 #prem5

# initializing win multipliers
lineFull = 3
line4 = 1.5
line3 = .5

multW = 4
multQ = .5
multK = .75
multA = 1
multP1 = 1.5
multP2 = 2
multP3 = 3
multP4 = 3.5
multP5 = 4

#starts game and asks for bet amount
if gameType == "lines":
    print(f"Balance: ${balance}")
    bet = input("How much would you like to bet?\nBet: $")
    while not bet.isdigit() or int(bet) < 5:
        print("Bet must be at least $5")
        bet = input("How much would you like to bet?\nBet: $")
    bet = int(bet)
    # initializing
    playing = True
    while playing:
        symbols = []
        balance -= bet
        print()
        for x in range(15):
            # randomly generates a number that corresponds to a symbol
            randomNum = random.randint(0, 1000)
            if randomNum >= 0 and randomNum < percent1: 
                symbols.append("W")
            if randomNum >= percent1 and randomNum < percent2 + percent1: 
                symbols.append("Q")
            if randomNum >= percent2 + percent1 and randomNum < percent3 + percent2 + percent1: 
                symbols.append("K")
            if randomNum >= percent3 + percent2 + percent1 and randomNum < percent4 + percent3 + percent2 + percent1: 
                symbols.append("A")
            if randomNum >= percent4 + percent3 + percent2 + percent1 and randomNum < percentP1 + percent4 + percent3 + percent2 + percent1: 
                symbols.append(prem1)
            if randomNum >= percentP1 + percent4 + percent3 + percent2 + percent1 and randomNum < percentP2 + percentP1 + percent4 + percent3 + percent2 + percent1: 
                symbols.append(prem2)
            if randomNum >= percentP2 + percentP1 + percent4 + percent3 + percent2 + percent1 and randomNum < percentP3 + percentP2 + percentP1 + percent4 + percent3 + percent2 + percent1: 
                symbols.append(prem3)
            if randomNum >= percentP3 + percentP2 + percentP1 + percent4 + percent3 + percent2 + percent1 and randomNum < percentP4 + percentP3 + percentP2 + percentP1 + percent4 + percent3 + percent2 + percent1: 
                symbols.append(prem4)
            if randomNum >= percentP4 + percentP3 + percentP2 + percentP1 + percent4 + percent3 + percent2 + percent1 and randomNum <= 1000: 
                symbols.append(prem5)   

        # puts randomly generated symbols into an array that correlates to the screen positions
        '''
        screen = [["K", "Q", "Q", "K", "K"],
                  ["K", "Q", "A", "X", "X"],
                  ["A", "A", "Q", "X", "X"]]
        '''
        screen = [[symbols[0], symbols[1], symbols[2], symbols[3], symbols[4]],
                  [symbols[5], symbols[6], symbols[7], symbols[8], symbols[9]],
                  [symbols[10], symbols[11], symbols[12], symbols[13], symbols[14]]]
        
                  

        # print screen
        i=0
        while i < 3:
            time.sleep(.5)
            print("%-2s %-2s %-2s %-2s %-2s" %(screen[i][0], screen[i][1], screen[i][2], screen[i][3], screen[i][4]))
            i += 1
            
        win = 0
        # calculates win based on lines
        # straight lines

        # first row straight lines
        if (screen[0][0] == screen[0][1] or screen[0][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[0][2] or screen[0][2] == "W") or (screen[0][1] == screen[0][2] or screen[0][2] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W"))) and ((screen[0][2] == screen[0][3] or screen[0][3] == "W") or (screen[0][3] == screen[0][2] or screen[0][3] == screen[0][1] or screen[0][3] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W" and screen[0][2] == "W"))) and ((screen[0][3] == screen[0][4] or screen[0][4] == "W") or (screen[0][4] == screen[0][3] or screen[0][4] == screen[0][2] or screen[0][4] == screen[0][1] or screen[0][4] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W" and screen[0][2] == "W" and screen[0][3] == "W"))):

            if screen[0][0] == "Q" or screen[0][1] == "Q" or screen[0][2] == "Q" or screen[0][3] == "Q" or screen[0][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[0][0] == "K" or screen[0][1] == "K" or screen[0][2] == "K" or screen[0][3] == "K" or screen[0][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[0][0] == "A" or screen[0][1] == "A" or screen[0][2] == "A" or screen[0][3] == "A" or screen[0][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[0][0] == prem1 or screen[0][1] == prem1 or screen[0][2] == prem1 or screen[0][3] == prem1 or screen[0][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[0][0] == prem2 or screen[0][1] == prem2 or screen[0][2] == prem2 or screen[0][3] == prem2 or screen[0][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[0][0] == prem3 or screen[0][1] == prem3 or screen[0][2] == prem3 or screen[0][3] == prem3 or screen[0][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[0][0] == prem4 or screen[0][1] == prem4 or screen[0][2] == prem4 or screen[0][3] == prem4 or screen[0][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[0][0] == prem5 or screen[0][1] == prem5 or screen[0][2] == prem5 or screen[0][3] == prem5 or screen[0][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[0][0] == screen[0][1] or screen[0][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[0][2] or screen[0][2] == "W") or (screen[0][1] == screen[0][2] or screen[0][2] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W"))) and ((screen[0][2] == screen[0][3] or screen[0][3] == "W") or (screen[0][3] == screen[0][2] or screen[0][3] == screen[0][1] or screen[0][3] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W" and screen[0][2] == "W"))):
            
            if screen[0][0] == "Q" or screen[0][1] == "Q" or screen[0][2] == "Q" or screen[0][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[0][0] == "K" or screen[0][1] == "K" or screen[0][2] == "K" or screen[0][3] == "K":
                win += line4*bet*multK
                
            elif screen[0][0] == "A" or screen[0][1] == "A" or screen[0][2] == "A" or screen[0][3] == "A":
                win += line4*bet*multA
                
            elif screen[0][0] == prem1 or screen[0][1] == prem1 or screen[0][2] == prem1 or screen[0][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[0][0] == prem2 or screen[0][1] == prem2 or screen[0][2] == prem2 or screen[0][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[0][0] == prem3 or screen[0][1] == prem3 or screen[0][2] == prem3 or screen[0][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[0][0] == prem4 or screen[0][1] == prem4 or screen[0][2] == prem4 or screen[0][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[0][0] == prem5 or screen[0][1] == prem5 or screen[0][2] == prem5 or screen[0][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[0][0] == screen[0][1] or screen[0][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[0][2] or screen[0][2] == "W") or (screen[0][1] == screen[0][2] or screen[0][2] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W"))):
            
            if screen[0][0] == "Q" or screen[0][1] == "Q" or screen[0][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[0][0] == "K" or screen[0][1] == "K" or screen[0][2] == "K":
                win += line3*bet*multK
                
            elif screen[0][0] == "A" or screen[0][1] == "A" or screen[0][2] == "A":
                win += line3*bet*multA
                
            elif screen[0][0] == prem1 or screen[0][1] == prem1 or screen[0][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[0][0] == prem2 or screen[0][1] == prem2 or screen[0][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[0][0] == prem3 or screen[0][1] == prem3 or screen[0][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[0][0] == prem4 or screen[0][1] == prem4 or screen[0][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[0][0] == prem5 or screen[0][1] == prem5 or screen[0][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

        # second row straight lines

        if (screen[1][0] == screen[1][1] or screen[1][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[1][2] or screen[1][2] == "W") or (screen[1][1] == screen[1][2] or screen[1][2] == screen[1][0] or (screen[1][0] == "W" and screen[1][1] == "W"))) and ((screen[1][2] == screen[1][3] or screen[1][3] == "W") or (screen[1][3] == screen[1][2] or screen[1][3] == screen[1][1] or screen[1][3] == screen[1][0] or (screen[1][0] == "W" and screen[1][1] == "W" and screen[1][2] == "W"))) and ((screen[1][3] == screen[1][4] or screen[1][4] == "W") or (screen[1][4] == screen[1][3] or screen[1][4] == screen[1][2] or screen[1][4] == screen[1][1] or screen[1][4] == screen[1][0] or (screen[1][0] == "W" and screen[1][1] == "W" and screen[1][2] == "W" and screen[1][3] == "W"))):

            if screen[1][0] == "Q" or screen[1][1] == "Q" or screen[1][2] == "Q" or screen[1][3] == "Q" or screen[1][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[1][0] == "K" or screen[1][1] == "K" or screen[1][2] == "K" or screen[1][3] == "K" or screen[1][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[1][0] == "A" or screen[1][1] == "A" or screen[1][2] == "A" or screen[1][3] == "A" or screen[1][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[1][0] == prem1 or screen[1][1] == prem1 or screen[1][2] == prem1 or screen[1][3] == prem1 or screen[1][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[1][0] == prem2 or screen[1][1] == prem2 or screen[1][2] == prem2 or screen[1][3] == prem2 or screen[1][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[1][0] == prem3 or screen[1][1] == prem3 or screen[1][2] == prem3 or screen[1][3] == prem3 or screen[1][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[1][0] == prem4 or screen[1][1] == prem4 or screen[1][2] == prem4 or screen[1][3] == prem4 or screen[1][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[1][0] == prem5 or screen[1][1] == prem5 or screen[1][2] == prem5 or screen[1][3] == prem5 or screen[1][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[1][0] == screen[1][1] or screen[1][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[1][2] or screen[1][2] == "W") or (screen[1][1] == screen[1][2] or screen[1][2] == screen[1][0] or (screen[1][0] == "W" and screen[1][1] == "W"))) and ((screen[1][2] == screen[1][3] or screen[1][3] == "W") or (screen[1][3] == screen[1][2] or screen[1][3] == screen[1][1] or screen[1][3] == screen[1][0] or (screen[1][0] == "W" and screen[1][1] == "W" and screen[1][2] == "W"))):
            
            if screen[1][0] == "Q" or screen[1][1] == "Q" or screen[1][2] == "Q" or screen[1][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[1][0] == "K" or screen[1][1] == "K" or screen[1][2] == "K" or screen[1][3] == "K":
                win += line4*bet*multK
                
            elif screen[1][0] == "A" or screen[1][1] == "A" or screen[1][2] == "A" or screen[1][3] == "A":
                win += line4*bet*multA
                
            elif screen[1][0] == prem1 or screen[1][1] == prem1 or screen[1][2] == prem1 or screen[1][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[1][0] == prem2 or screen[1][1] == prem2 or screen[1][2] == prem2 or screen[1][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[1][0] == prem3 or screen[1][1] == prem3 or screen[1][2] == prem3 or screen[1][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[1][0] == prem4 or screen[1][1] == prem4 or screen[1][2] == prem4 or screen[1][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[1][0] == prem5 or screen[1][1] == prem5 or screen[1][2] == prem5 or screen[1][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[1][0] == screen[1][1] or screen[1][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[1][2] or screen[1][2] == "W") or (screen[1][1] == screen[1][2] or screen[1][2] == screen[1][0] or (screen[1][0] == "W" and screen[1][1] == "W"))):
            
            if screen[1][0] == "Q" or screen[1][1] == "Q" or screen[1][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[1][0] == "K" or screen[1][1] == "K" or screen[1][2] == "K":
                win += line3*bet*multK
                
            elif screen[1][0] == "A" or screen[1][1] == "A" or screen[1][2] == "A":
                win += line3*bet*multA
                
            elif screen[1][0] == prem1 or screen[1][1] == prem1 or screen[1][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[1][0] == prem2 or screen[1][1] == prem2 or screen[1][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[1][0] == prem3 or screen[1][1] == prem3 or screen[1][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[1][0] == prem4 or screen[1][1] == prem4 or screen[1][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[1][0] == prem5 or screen[1][1] == prem5 or screen[1][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

        # third row straight lines

        if (screen[2][0] == screen[2][1] or screen[2][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[2][2] or screen[2][2] == "W") or (screen[2][1] == screen[2][2] or screen[2][2] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W"))) and ((screen[2][2] == screen[2][3] or screen[2][3] == "W") or (screen[2][3] == screen[2][2] or screen[2][3] == screen[2][1] or screen[2][3] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W" and screen[2][2] == "W"))) and ((screen[2][3] == screen[2][4] or screen[2][4] == "W") or (screen[2][4] == screen[2][3] or screen[2][4] == screen[2][2] or screen[2][4] == screen[2][1] or screen[2][4] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W" and screen[2][2] == "W" and screen[2][3] == "W"))):

            if screen[2][0] == "Q" or screen[2][1] == "Q" or screen[2][2] == "Q" or screen[2][3] == "Q" or screen[2][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[2][0] == "K" or screen[2][1] == "K" or screen[2][2] == "K" or screen[2][3] == "K" or screen[2][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[2][0] == "A" or screen[2][1] == "A" or screen[2][2] == "A" or screen[2][3] == "A" or screen[2][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[2][0] == prem1 or screen[2][1] == prem1 or screen[2][2] == prem1 or screen[2][3] == prem1 or screen[2][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[2][0] == prem2 or screen[2][1] == prem2 or screen[2][2] == prem2 or screen[2][3] == prem2 or screen[2][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[2][0] == prem3 or screen[2][1] == prem3 or screen[2][2] == prem3 or screen[2][3] == prem3 or screen[2][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[2][0] == prem4 or screen[2][1] == prem4 or screen[2][2] == prem4 or screen[2][3] == prem4 or screen[2][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[2][0] == prem5 or screen[2][1] == prem5 or screen[2][2] == prem5 or screen[2][3] == prem5 or screen[2][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[2][0] == screen[2][1] or screen[2][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[2][2] or screen[2][2] == "W") or (screen[2][1] == screen[2][2] or screen[2][2] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W"))) and ((screen[2][2] == screen[2][3] or screen[2][3] == "W") or (screen[2][3] == screen[2][2] or screen[2][3] == screen[2][1] or screen[2][3] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W" and screen[2][2] == "W"))):
            
            if screen[2][0] == "Q" or screen[2][1] == "Q" or screen[2][2] == "Q" or screen[2][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[2][0] == "K" or screen[2][1] == "K" or screen[2][2] == "K" or screen[2][3] == "K":
                win += line4*bet*multK
                
            elif screen[2][0] == "A" or screen[2][1] == "A" or screen[2][2] == "A" or screen[2][3] == "A":
                win += line4*bet*multA
                
            elif screen[2][0] == prem1 or screen[2][1] == prem1 or screen[2][2] == prem1 or screen[2][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[2][0] == prem2 or screen[2][1] == prem2 or screen[2][2] == prem2 or screen[2][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[2][0] == prem3 or screen[2][1] == prem3 or screen[2][2] == prem3 or screen[2][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[2][0] == prem4 or screen[2][1] == prem4 or screen[2][2] == prem4 or screen[2][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[2][0] == prem5 or screen[2][1] == prem5 or screen[2][2] == prem5 or screen[2][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[2][0] == screen[2][1] or screen[2][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[2][2] or screen[2][2] == "W") or (screen[2][1] == screen[2][2] or screen[2][2] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W"))):
            
            if screen[2][0] == "Q" or screen[2][1] == "Q" or screen[2][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[2][0] == "K" or screen[2][1] == "K" or screen[2][2] == "K":
                win += line3*bet*multK
                
            elif screen[2][0] == "A" or screen[2][1] == "A" or screen[2][2] == "A":
                win += line3*bet*multA
                
            elif screen[2][0] == prem1 or screen[2][1] == prem1 or screen[2][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[2][0] == prem2 or screen[2][1] == prem2 or screen[2][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[2][0] == prem3 or screen[2][1] == prem3 or screen[2][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[2][0] == prem4 or screen[2][1] == prem4 or screen[2][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[2][0] == prem5 or screen[2][1] == prem5 or screen[2][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

        # V shapes
        
        # V shape down

        if (screen[0][0] == screen[1][1] or screen[0][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[2][2] or screen[2][2] == "W") or (screen[1][1] == screen[2][2] or screen[2][2] == screen[0][0] or (screen[0][0] == "W" and screen[1][1] == "W"))) and ((screen[2][2] == screen[1][3] or screen[1][3] == "W") or (screen[1][3] == screen[2][2] or screen[1][3] == screen[1][1] or screen[1][3] == screen[0][0] or (screen[0][0] == "W" and screen[1][1] == "W" and screen[2][2] == "W"))) and ((screen[1][3] == screen[0][4] or screen[0][4] == "W") or (screen[0][4] == screen[1][3] or screen[0][4] == screen[2][2] or screen[0][4] == screen[1][1] or screen[0][4] == screen[0][0] or (screen[0][0] == "W" and screen[1][1] == "W" and screen[2][2] == "W" and screen[1][3] == "W"))):

            if screen[0][0] == "Q" or screen[1][1] == "Q" or screen[2][2] == "Q" or screen[1][3] == "Q" or screen[0][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[0][0] == "K" or screen[1][1] == "K" or screen[2][2] == "K" or screen[1][3] == "K" or screen[0][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[0][0] == "A" or screen[1][1] == "A" or screen[2][2] == "A" or screen[1][3] == "A" or screen[0][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[0][0] == prem1 or screen[1][1] == prem1 or screen[2][2] == prem1 or screen[1][3] == prem1 or screen[0][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[0][0] == prem2 or screen[1][1] == prem2 or screen[2][2] == prem2 or screen[1][3] == prem2 or screen[0][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[0][0] == prem3 or screen[1][1] == prem3 or screen[2][2] == prem3 or screen[1][3] == prem3 or screen[0][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[0][0] == prem4 or screen[1][1] == prem4 or screen[2][2] == prem4 or screen[1][3] == prem4 or screen[0][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[0][0] == prem5 or screen[1][1] == prem5 or screen[2][2] == prem5 or screen[1][3] == prem5 or screen[0][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[0][0] == screen[1][1] or screen[0][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[2][2] or screen[2][2] == "W") or (screen[1][1] == screen[2][2] or screen[2][2] == screen[0][0] or (screen[0][0] == "W" and screen[1][1] == "W"))) and ((screen[2][2] == screen[1][3] or screen[1][3] == "W") or (screen[1][3] == screen[2][2] or screen[1][3] == screen[1][1] or screen[1][3] == screen[0][0] or (screen[0][0] == "W" and screen[1][1] == "W" and screen[2][2] == "W"))):
            
            if screen[0][0] == "Q" or screen[1][1] == "Q" or screen[2][2] == "Q" or screen[1][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[0][0] == "K" or screen[1][1] == "K" or screen[2][2] == "K" or screen[1][3] == "K":
                win += line4*bet*multK
                
            elif screen[0][0] == "A" or screen[1][1] == "A" or screen[2][2] == "A" or screen[1][3] == "A":
                win += line4*bet*multA
                
            elif screen[0][0] == prem1 or screen[1][1] == prem1 or screen[2][2] == prem1 or screen[1][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[0][0] == prem2 or screen[1][1] == prem2 or screen[2][2] == prem2 or screen[1][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[0][0] == prem3 or screen[1][1] == prem3 or screen[2][2] == prem3 or screen[1][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[0][0] == prem4 or screen[1][1] == prem4 or screen[2][2] == prem4 or screen[1][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[0][0] == prem5 or screen[1][1] == prem5 or screen[2][2] == prem5 or screen[1][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[0][0] == screen[1][1] or screen[0][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[2][2] or screen[2][2] == "W") or (screen[1][1] == screen[2][2] or screen[2][2] == screen[0][0] or (screen[0][0] == "W" and screen[1][1] == "W"))):
            
            if screen[0][0] == "Q" or screen[1][1] == "Q" or screen[2][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[0][0] == "K" or screen[1][1] == "K" or screen[2][2] == "K":
                win += line3*bet*multK
                
            elif screen[0][0] == "A" or screen[1][1] == "A" or screen[2][2] == "A":
                win += line3*bet*multA
                
            elif screen[0][0] == prem1 or screen[1][1] == prem1 or screen[2][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[0][0] == prem2 or screen[1][1] == prem2 or screen[2][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[0][0] == prem3 or screen[1][1] == prem3 or screen[2][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[0][0] == prem4 or screen[1][1] == prem4 or screen[2][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[0][0] == prem5 or screen[1][1] == prem5 or screen[2][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

            # V shape up

        if (screen[2][0] == screen[1][1] or screen[2][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[0][2] or screen[0][2] == "W") or (screen[1][1] == screen[0][2] or screen[0][2] == screen[2][0] or (screen[2][0] == "W" and screen[1][1] == "W"))) and ((screen[0][2] == screen[1][3] or screen[1][3] == "W") or (screen[1][3] == screen[0][2] or screen[1][3] == screen[1][1] or screen[1][3] == screen[2][0] or (screen[2][0] == "W" and screen[1][1] == "W" and screen[0][2] == "W"))) and ((screen[1][3] == screen[2][4] or screen[2][4] == "W") or (screen[2][4] == screen[1][3] or screen[2][4] == screen[0][2] or screen[2][4] == screen[1][1] or screen[2][4] == screen[2][0] or (screen[2][0] == "W" and screen[1][1] == "W" and screen[0][2] == "W" and screen[1][3] == "W"))):

            if screen[2][0] == "Q" or screen[1][1] == "Q" or screen[0][2] == "Q" or screen[1][3] == "Q" or screen[2][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[2][0] == "K" or screen[1][1] == "K" or screen[0][2] == "K" or screen[1][3] == "K" or screen[2][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[2][0] == "A" or screen[1][1] == "A" or screen[0][2] == "A" or screen[1][3] == "A" or screen[2][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[2][0] == prem1 or screen[1][1] == prem1 or screen[0][2] == prem1 or screen[1][3] == prem1 or screen[2][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[2][0] == prem2 or screen[1][1] == prem2 or screen[0][2] == prem2 or screen[1][3] == prem2 or screen[2][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[2][0] == prem3 or screen[1][1] == prem3 or screen[0][2] == prem3 or screen[1][3] == prem3 or screen[2][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[2][0] == prem4 or screen[1][1] == prem4 or screen[0][2] == prem4 or screen[1][3] == prem4 or screen[2][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[2][0] == prem5 or screen[1][1] == prem5 or screen[0][2] == prem5 or screen[1][3] == prem5 or screen[2][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[2][0] == screen[1][1] or screen[2][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[0][2] or screen[0][2] == "W") or (screen[1][1] == screen[0][2] or screen[0][2] == screen[2][0] or (screen[2][0] == "W" and screen[1][1] == "W"))) and ((screen[0][2] == screen[1][3] or screen[1][3] == "W") or (screen[1][3] == screen[0][2] or screen[1][3] == screen[1][1] or screen[1][3] == screen[2][0] or (screen[2][0] == "W" and screen[1][1] == "W" and screen[0][2] == "W"))):
            
            if screen[2][0] == "Q" or screen[1][1] == "Q" or screen[0][2] == "Q" or screen[1][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[2][0] == "K" or screen[1][1] == "K" or screen[0][2] == "K" or screen[1][3] == "K":
                win += line4*bet*multK
                
            elif screen[2][0] == "A" or screen[1][1] == "A" or screen[0][2] == "A" or screen[1][3] == "A":
                win += line4*bet*multA
                
            elif screen[2][0] == prem1 or screen[1][1] == prem1 or screen[0][2] == prem1 or screen[1][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[2][0] == prem2 or screen[1][1] == prem2 or screen[0][2] == prem2 or screen[1][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[2][0] == prem3 or screen[1][1] == prem3 or screen[0][2] == prem3 or screen[1][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[2][0] == prem4 or screen[1][1] == prem4 or screen[0][2] == prem4 or screen[1][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[2][0] == prem5 or screen[1][1] == prem5 or screen[0][2] == prem5 or screen[1][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[2][0] == screen[1][1] or screen[2][0] == "W" or screen[1][1] == "W") and ((screen[1][1] == screen[0][2] or screen[0][2] == "W") or (screen[1][1] == screen[0][2] or screen[0][2] == screen[2][0] or (screen[2][0] == "W" and screen[1][1] == "W"))):
            
            if screen[2][0] == "Q" or screen[1][1] == "Q" or screen[0][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[2][0] == "K" or screen[1][1] == "K" or screen[0][2] == "K":
                win += line3*bet*multK
                
            elif screen[2][0] == "A" or screen[1][1] == "A" or screen[0][2] == "A":
                win += line3*bet*multA
                
            elif screen[2][0] == prem1 or screen[1][1] == prem1 or screen[0][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[2][0] == prem2 or screen[1][1] == prem2 or screen[0][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[2][0] == prem3 or screen[1][1] == prem3 or screen[0][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[2][0] == prem4 or screen[1][1] == prem4 or screen[0][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[2][0] == prem5 or screen[1][1] == prem5 or screen[0][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

        # Hexagon shapes

        # Hexagon shape up

        if (screen[1][0] == screen[0][1] or screen[1][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[0][2] or screen[0][2] == "W") or (screen[0][1] == screen[0][2] or screen[0][2] == screen[1][0] or (screen[1][0] == "W" and screen[0][1] == "W"))) and ((screen[0][2] == screen[0][3] or screen[0][3] == "W") or (screen[0][3] == screen[0][2] or screen[0][3] == screen[0][1] or screen[0][3] == screen[1][0] or (screen[1][0] == "W" and screen[0][1] == "W" and screen[0][2] == "W"))) and ((screen[0][3] == screen[1][4] or screen[1][4] == "W") or (screen[1][4] == screen[0][3] or screen[1][4] == screen[0][2] or screen[1][4] == screen[0][1] or screen[1][4] == screen[1][0] or (screen[1][0] == "W" and screen[0][1] == "W" and screen[0][2] == "W" and screen[0][3] == "W"))):

            if screen[1][0] == "Q" or screen[0][1] == "Q" or screen[0][2] == "Q" or screen[0][3] == "Q" or screen[1][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[1][0] == "K" or screen[0][1] == "K" or screen[0][2] == "K" or screen[0][3] == "K" or screen[1][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[1][0] == "A" or screen[0][1] == "A" or screen[0][2] == "A" or screen[0][3] == "A" or screen[1][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[1][0] == prem1 or screen[0][1] == prem1 or screen[0][2] == prem1 or screen[0][3] == prem1 or screen[1][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[1][0] == prem2 or screen[0][1] == prem2 or screen[0][2] == prem2 or screen[0][3] == prem2 or screen[1][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[1][0] == prem3 or screen[0][1] == prem3 or screen[0][2] == prem3 or screen[0][3] == prem3 or screen[1][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[1][0] == prem4 or screen[0][1] == prem4 or screen[0][2] == prem4 or screen[0][3] == prem4 or screen[1][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[1][0] == prem5 or screen[0][1] == prem5 or screen[0][2] == prem5 or screen[0][3] == prem5 or screen[1][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[1][0] == screen[0][1] or screen[1][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[0][2] or screen[0][2] == "W") or (screen[0][1] == screen[0][2] or screen[0][2] == screen[1][0] or (screen[1][0] == "W" and screen[0][1] == "W"))) and ((screen[0][2] == screen[0][3] or screen[0][3] == "W") or (screen[0][3] == screen[0][2] or screen[0][3] == screen[0][1] or screen[0][3] == screen[1][0] or (screen[1][0] == "W" and screen[0][1] == "W" and screen[0][2] == "W"))):
            
            if screen[1][0] == "Q" or screen[0][1] == "Q" or screen[0][2] == "Q" or screen[0][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[1][0] == "K" or screen[0][1] == "K" or screen[0][2] == "K" or screen[0][3] == "K":
                win += line4*bet*multK
                
            elif screen[1][0] == "A" or screen[0][1] == "A" or screen[0][2] == "A" or screen[0][3] == "A":
                win += line4*bet*multA
                
            elif screen[1][0] == prem1 or screen[0][1] == prem1 or screen[0][2] == prem1 or screen[0][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[1][0] == prem2 or screen[0][1] == prem2 or screen[0][2] == prem2 or screen[0][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[1][0] == prem3 or screen[0][1] == prem3 or screen[0][2] == prem3 or screen[0][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[1][0] == prem4 or screen[0][1] == prem4 or screen[0][2] == prem4 or screen[0][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[1][0] == prem5 or screen[0][1] == prem5 or screen[0][2] == prem5 or screen[0][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[1][0] == screen[0][1] or screen[1][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[0][2] or screen[0][2] == "W") or (screen[0][1] == screen[0][2] or screen[0][2] == screen[1][0] or (screen[1][0] == "W" and screen[0][1] == "W"))):
            
            if screen[1][0] == "Q" or screen[0][1] == "Q" or screen[0][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[1][0] == "K" or screen[0][1] == "K" or screen[0][2] == "K":
                win += line3*bet*multK
                
            elif screen[1][0] == "A" or screen[0][1] == "A" or screen[0][2] == "A":
                win += line3*bet*multA
                
            elif screen[1][0] == prem1 or screen[0][1] == prem1 or screen[0][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[1][0] == prem2 or screen[0][1] == prem2 or screen[0][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[1][0] == prem3 or screen[0][1] == prem3 or screen[0][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[1][0] == prem4 or screen[0][1] == prem4 or screen[0][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[1][0] == prem5 or screen[0][1] == prem5 or screen[0][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

        # Hexagon shape down

        if (screen[1][0] == screen[2][1] or screen[1][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[2][2] or screen[2][2] == "W") or (screen[2][1] == screen[2][2] or screen[2][2] == screen[1][0] or (screen[1][0] == "W" and screen[2][1] == "W"))) and ((screen[2][2] == screen[2][3] or screen[2][3] == "W") or (screen[2][3] == screen[2][2] or screen[2][3] == screen[2][1] or screen[2][3] == screen[1][0] or (screen[1][0] == "W" and screen[2][1] == "W" and screen[2][2] == "W"))) and ((screen[2][3] == screen[1][4] or screen[1][4] == "W") or (screen[1][4] == screen[2][3] or screen[1][4] == screen[2][2] or screen[1][4] == screen[2][1] or screen[1][4] == screen[1][0] or (screen[1][0] == "W" and screen[2][1] == "W" and screen[2][2] == "W" and screen[2][3] == "W"))):

            if screen[1][0] == "Q" or screen[2][1] == "Q" or screen[2][2] == "Q" or screen[2][3] == "Q" or screen[1][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[1][0] == "K" or screen[2][1] == "K" or screen[2][2] == "K" or screen[2][3] == "K" or screen[1][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[1][0] == "A" or screen[2][1] == "A" or screen[2][2] == "A" or screen[2][3] == "A" or screen[1][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[1][0] == prem1 or screen[2][1] == prem1 or screen[2][2] == prem1 or screen[2][3] == prem1 or screen[1][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[1][0] == prem2 or screen[2][1] == prem2 or screen[2][2] == prem2 or screen[2][3] == prem2 or screen[1][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[1][0] == prem3 or screen[2][1] == prem3 or screen[2][2] == prem3 or screen[2][3] == prem3 or screen[1][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[1][0] == prem4 or screen[2][1] == prem4 or screen[2][2] == prem4 or screen[2][3] == prem4 or screen[1][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[1][0] == prem5 or screen[2][1] == prem5 or screen[2][2] == prem5 or screen[2][3] == prem5 or screen[1][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[1][0] == screen[2][1] or screen[1][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[2][2] or screen[2][2] == "W") or (screen[2][1] == screen[2][2] or screen[2][2] == screen[1][0] or (screen[1][0] == "W" and screen[2][1] == "W"))) and ((screen[2][2] == screen[2][3] or screen[2][3] == "W") or (screen[2][3] == screen[2][2] or screen[2][3] == screen[2][1] or screen[2][3] == screen[1][0] or (screen[1][0] == "W" and screen[2][1] == "W" and screen[2][2] == "W"))):
            
            if screen[1][0] == "Q" or screen[2][1] == "Q" or screen[2][2] == "Q" or screen[2][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[1][0] == "K" or screen[2][1] == "K" or screen[2][2] == "K" or screen[2][3] == "K":
                win += line4*bet*multK
                
            elif screen[1][0] == "A" or screen[2][1] == "A" or screen[2][2] == "A" or screen[2][3] == "A":
                win += line4*bet*multA
                
            elif screen[1][0] == prem1 or screen[2][1] == prem1 or screen[2][2] == prem1 or screen[2][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[1][0] == prem2 or screen[2][1] == prem2 or screen[2][2] == prem2 or screen[2][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[1][0] == prem3 or screen[2][1] == prem3 or screen[2][2] == prem3 or screen[2][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[1][0] == prem4 or screen[2][1] == prem4 or screen[2][2] == prem4 or screen[2][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[1][0] == prem5 or screen[2][1] == prem5 or screen[2][2] == prem5 or screen[2][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[1][0] == screen[2][1] or screen[1][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[2][2] or screen[2][2] == "W") or (screen[2][1] == screen[2][2] or screen[2][2] == screen[1][0] or (screen[1][0] == "W" and screen[2][1] == "W"))):
            
            if screen[1][0] == "Q" or screen[2][1] == "Q" or screen[2][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[1][0] == "K" or screen[2][1] == "K" or screen[2][2] == "K":
                win += line3*bet*multK
                
            elif screen[1][0] == "A" or screen[2][1] == "A" or screen[2][2] == "A":
                win += line3*bet*multA
                
            elif screen[1][0] == prem1 or screen[2][1] == prem1 or screen[2][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[1][0] == prem2 or screen[2][1] == prem2 or screen[2][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[1][0] == prem3 or screen[2][1] == prem3 or screen[2][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[1][0] == prem4 or screen[2][1] == prem4 or screen[2][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[1][0] == prem5 or screen[2][1] == prem5 or screen[2][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

            # S lines

            # S line starting down

        if (screen[2][0] == screen[2][1] or screen[2][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[1][2] or screen[1][2] == "W") or (screen[2][1] == screen[1][2] or screen[1][2] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W"))) and ((screen[1][2] == screen[0][3] or screen[0][3] == "W") or (screen[0][3] == screen[1][2] or screen[0][3] == screen[2][1] or screen[0][3] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W" and screen[1][2] == "W"))) and ((screen[0][3] == screen[0][4] or screen[0][4] == "W") or (screen[0][4] == screen[0][3] or screen[0][4] == screen[1][2] or screen[0][4] == screen[2][1] or screen[0][4] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W" and screen[1][2] == "W" and screen[0][3] == "W"))):

            if screen[2][0] == "Q" or screen[2][1] == "Q" or screen[1][2] == "Q" or screen[0][3] == "Q" or screen[0][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[2][0] == "K" or screen[2][1] == "K" or screen[1][2] == "K" or screen[0][3] == "K" or screen[0][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[2][0] == "A" or screen[2][1] == "A" or screen[1][2] == "A" or screen[0][3] == "A" or screen[0][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[2][0] == prem1 or screen[2][1] == prem1 or screen[1][2] == prem1 or screen[0][3] == prem1 or screen[0][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[2][0] == prem2 or screen[2][1] == prem2 or screen[1][2] == prem2 or screen[0][3] == prem2 or screen[0][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[2][0] == prem3 or screen[2][1] == prem3 or screen[1][2] == prem3 or screen[0][3] == prem3 or screen[0][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[2][0] == prem4 or screen[2][1] == prem4 or screen[1][2] == prem4 or screen[0][3] == prem4 or screen[0][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[2][0] == prem5 or screen[2][1] == prem5 or screen[1][2] == prem5 or screen[0][3] == prem5 or screen[0][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[2][0] == screen[2][1] or screen[2][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[1][2] or screen[1][2] == "W") or (screen[2][1] == screen[1][2] or screen[1][2] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W"))) and ((screen[1][2] == screen[0][3] or screen[0][3] == "W") or (screen[0][3] == screen[1][2] or screen[0][3] == screen[2][1] or screen[0][3] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W" and screen[1][2] == "W"))):
            
            if screen[2][0] == "Q" or screen[2][1] == "Q" or screen[1][2] == "Q" or screen[0][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[2][0] == "K" or screen[2][1] == "K" or screen[1][2] == "K" or screen[0][3] == "K":
                win += line4*bet*multK
                
            elif screen[2][0] == "A" or screen[2][1] == "A" or screen[1][2] == "A" or screen[0][3] == "A":
                win += line4*bet*multA
                
            elif screen[2][0] == prem1 or screen[2][1] == prem1 or screen[1][2] == prem1 or screen[0][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[2][0] == prem2 or screen[2][1] == prem2 or screen[1][2] == prem2 or screen[0][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[2][0] == prem3 or screen[2][1] == prem3 or screen[1][2] == prem3 or screen[0][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[2][0] == prem4 or screen[2][1] == prem4 or screen[1][2] == prem4 or screen[0][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[2][0] == prem5 or screen[2][1] == prem5 or screen[1][2] == prem5 or screen[0][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[2][0] == screen[2][1] or screen[2][0] == "W" or screen[2][1] == "W") and ((screen[2][1] == screen[1][2] or screen[1][2] == "W") or (screen[2][1] == screen[1][2] or screen[1][2] == screen[2][0] or (screen[2][0] == "W" and screen[2][1] == "W"))):
            
            if screen[2][0] == "Q" or screen[2][1] == "Q" or screen[1][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[2][0] == "K" or screen[2][1] == "K" or screen[1][2] == "K":
                win += line3*bet*multK
                
            elif screen[2][0] == "A" or screen[2][1] == "A" or screen[1][2] == "A":
                win += line3*bet*multA
                
            elif screen[2][0] == prem1 or screen[2][1] == prem1 or screen[1][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[2][0] == prem2 or screen[2][1] == prem2 or screen[1][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[2][0] == prem3 or screen[2][1] == prem3 or screen[1][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[2][0] == prem4 or screen[2][1] == prem4 or screen[1][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[2][0] == prem5 or screen[2][1] == prem5 or screen[1][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW

        # S line starting up

        if (screen[0][0] == screen[0][1] or screen[0][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[1][2] or screen[1][2] == "W") or (screen[0][1] == screen[1][2] or screen[1][2] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W"))) and ((screen[1][2] == screen[2][3] or screen[2][3] == "W") or (screen[2][3] == screen[1][2] or screen[2][3] == screen[0][1] or screen[2][3] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W" and screen[1][2] == "W"))) and ((screen[2][3] == screen[2][4] or screen[2][4] == "W") or (screen[2][4] == screen[2][3] or screen[2][4] == screen[1][2] or screen[2][4] == screen[0][1] or screen[2][4] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W" and screen[1][2] == "W" and screen[2][3] == "W"))):

            if screen[0][0] == "Q" or screen[0][1] == "Q" or screen[1][2] == "Q" or screen[2][3] == "Q" or screen[2][4] == "Q":
                win += lineFull*bet*multQ
                
            elif screen[0][0] == "K" or screen[0][1] == "K" or screen[1][2] == "K" or screen[2][3] == "K" or screen[2][4] == "K":
                win += lineFull*bet*multK
                
            elif screen[0][0] == "A" or screen[0][1] == "A" or screen[1][2] == "A" or screen[2][3] == "A" or screen[2][4] == "A":
                win += lineFull*bet*multA
                
            elif screen[0][0] == prem1 or screen[0][1] == prem1 or screen[1][2] == prem1 or screen[2][3] == prem1 or screen[2][4] == prem1:
                win += lineFull*bet*multP1
                
            elif screen[0][0] == prem2 or screen[0][1] == prem2 or screen[1][2] == prem2 or screen[2][3] == prem2 or screen[2][4] == prem2:
                win += lineFull*bet*multP2
                
            elif screen[0][0] == prem3 or screen[0][1] == prem3 or screen[1][2] == prem3 or screen[2][3] == prem3 or screen[2][4] == prem3:
                win += lineFull*bet*multP3
                
            elif screen[0][0] == prem4 or screen[0][1] == prem4 or screen[1][2] == prem4 or screen[2][3] == prem4 or screen[2][4] == prem4:
                win += lineFull*bet*multP4
                
            elif screen[0][0] == prem5 or screen[0][1] == prem5 or screen[1][2] == prem5 or screen[2][3] == prem5 or screen[2][4] == prem5:
                win += lineFull*bet*multP5
                
            else:
                win += lineFull*bet*multW

                
        elif (screen[0][0] == screen[0][1] or screen[0][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[1][2] or screen[1][2] == "W") or (screen[0][1] == screen[1][2] or screen[1][2] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W"))) and ((screen[1][2] == screen[2][3] or screen[2][3] == "W") or (screen[2][3] == screen[1][2] or screen[2][3] == screen[0][1] or screen[2][3] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W" and screen[1][2] == "W"))):
            
            if screen[0][0] == "Q" or screen[0][1] == "Q" or screen[1][2] == "Q" or screen[2][3] == "Q":
                win += line4*bet*multQ
                
            elif screen[0][0] == "K" or screen[0][1] == "K" or screen[1][2] == "K" or screen[2][3] == "K":
                win += line4*bet*multK
                
            elif screen[0][0] == "A" or screen[0][1] == "A" or screen[1][2] == "A" or screen[2][3] == "A":
                win += line4*bet*multA
                
            elif screen[0][0] == prem1 or screen[0][1] == prem1 or screen[1][2] == prem1 or screen[2][3] == prem1:
                win += line4*bet*multP1
                
            elif screen[0][0] == prem2 or screen[0][1] == prem2 or screen[1][2] == prem2 or screen[2][3] == prem2:
                win += line4*bet*multP2
                
            elif screen[0][0] == prem3 or screen[0][1] == prem3 or screen[1][2] == prem3 or screen[2][3] == prem3:
                win += line4*bet*multP3
                
            elif screen[0][0] == prem4 or screen[0][1] == prem4 or screen[1][2] == prem4 or screen[2][3] == prem4:
                win += line4*bet*multP4
                
            elif screen[0][0] == prem5 or screen[0][1] == prem5 or screen[1][2] == prem5 or screen[2][3] == prem5:
                win += line4*bet*multP5
                
            else:
                win += line4*bet*multW
                
        elif (screen[0][0] == screen[0][1] or screen[0][0] == "W" or screen[0][1] == "W") and ((screen[0][1] == screen[1][2] or screen[1][2] == "W") or (screen[0][1] == screen[1][2] or screen[1][2] == screen[0][0] or (screen[0][0] == "W" and screen[0][1] == "W"))):
            
            if screen[0][0] == "Q" or screen[0][1] == "Q" or screen[1][2] == "Q":
                win += line3*bet*multQ
                
            elif screen[0][0] == "K" or screen[0][1] == "K" or screen[1][2] == "K":
                win += line3*bet*multK
                
            elif screen[0][0] == "A" or screen[0][1] == "A" or screen[1][2] == "A":
                win += line3*bet*multA
                
            elif screen[0][0] == prem1 or screen[0][1] == prem1 or screen[1][2] == prem1:
                win += line3*bet*multP1
                
            elif screen[0][0] == prem2 or screen[0][1] == prem2 or screen[1][2] == prem2:
                win += line3*bet*multP2
                
            elif screen[0][0] == prem3 or screen[0][1] == prem3 or screen[1][2] == prem3:
                win += line3*bet*multP3
                
            elif screen[0][0] == prem4 or screen[0][1] == prem4 or screen[1][2] == prem4:
                win += line3*bet*multP4
                
            elif screen[0][0] == prem5 or screen[0][1] == prem5 or screen[1][2] == prem5:
                win += line3*bet*multP5
                
            else:
                win += line3*bet*multW



        
        # add win to balance
        balance += int(math.ceil(win))
        time.sleep(.6)
        print()
        if win > bet*100:
            print(f"HUGE WIN!! ${int(math.ceil(win))}")
            print()
        elif win > bet*10:
            print(f"Big win! ${int(math.ceil(win))}")
            print()
        elif win > 0:
            print(f"Congrats you won ${int(math.ceil(win))}!")
            print()
        else:
            print("no win")
            
        # prompt user for next action
        time.sleep(.5)
        print()
        print(f"Balance: ${balance}")
        print(f"Bet: ${bet}")
        print("1) spin again")
        print("2) change bet")
        print("3) cash out")
        choice = input("What would you like to do: ")
        while choice != "1" and choice != "2" and choice != "3":
            print("Please enter a valid choice")
            choice = input("What would you like to do: ")
            
        if choice == "1":
            playing = True
        elif choice == "2":
            bet = input("How much would you like to bet?\nBet: $")
            while not bet.isdigit() or int(bet) < 5:
                print("Bet must be at least $5")
                bet = input("How much would you like to bet?\nBet: $")
            bet = int(bet)
        elif choice == "3":
            playing = False

    print("Thanks for playing")
    print(f"Balance: ${balance}")
    
